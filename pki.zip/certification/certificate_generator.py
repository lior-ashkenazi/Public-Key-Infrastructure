from certification.certificate_authority import CertificateAuthority

from certification.utils import key_for_entity

class CertificateGenerator:
    @staticmethod
    def generate_certificate(ca_name, ca_cert=None, ca_key=None, entity_name=None,is_ca=True):
        # Note that here there are two options:
        # 1. Either we load an already generated root certificate authority,
        # 2. Or we generate a new one.
        ca = CertificateAuthority(ca_name=ca_name,ca_cert=ca_cert,ca_key=ca_key)

        if not entity_name:
            # Just *generate* the root certificate
            ca_cert, ca_key = ca.generate_root_ca_certificate()
            return ca_cert, ca_key, key_for_entity(ca_name)

        else:
            if is_ca:
                # Sign a certificate for a given entity which
                # also going to be a Certificate Authority
                ca_cert, ca_key = ca.generate_certificate_authority_entity(entity_name)
                cert, key = ca_cert, ca_key
            else:
                # Sign a certificate for a given entity which
                # also going to be a Certificate Authority
                cert, key = ca.generate_certificate_entity(entity_name)
            return cert, key, key_for_entity(entity_name)
