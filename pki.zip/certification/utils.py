import os

import datetime

from certification.config import CERTS_DIR, DATE_FORMAT_ASN1

from OpenSSL import crypto
from OpenSSL.SSL import FILETYPE_PEM

import random


def key_for_entity(entity_name):
    return os.path.join(CERTS_DIR, entity_name) + '.pem'


def key_for_entity_crl(entity_name):
    return os.path.join(CERTS_DIR, entity_name) + '.crl.pem'


def write_pem(buff, cert, key):
    buff.write(crypto.dump_privatekey(FILETYPE_PEM, key))
    buff.write(crypto.dump_certificate(FILETYPE_PEM, cert))
    return buff


def read_pem(buff):
    cert = crypto.load_certificate(FILETYPE_PEM, buff.read())
    buff.seek(0)
    key = crypto.load_privatekey(FILETYPE_PEM, buff.read())
    return cert, key


def get_random_serial_number():
    return random.randint(0, (2 ** 64) - 1)


def get_current_time(date_str=DATE_FORMAT_ASN1):
    now = datetime.datetime.now()
    return now.strftime(date_str).encode()


def int_to_hex(num):
    return format(num, "02x")


def hex_to_int(hex_str):
    return int(hex_str, 16)
