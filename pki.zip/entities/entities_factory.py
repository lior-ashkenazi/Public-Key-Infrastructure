from entities.entity import Entity
from entities.ca_entity import CertificateAuthorityEntity


class EntitiesFactory:
    available_counter: int = 1

    @staticmethod
    def _generate_entity_id():
        entity_id = EntitiesFactory.available_counter
        EntitiesFactory.available_counter += 1
        return entity_id

    @staticmethod
    def generate_root_certificate_authority():
        entity_id = EntitiesFactory._generate_entity_id()
        entity = CertificateAuthorityEntity(entity_id)
        return entity_id, entity

    @staticmethod
    def generate_certificate_authority(ca_entity):
        entity_id = EntitiesFactory._generate_entity_id()
        entity = CertificateAuthorityEntity(entity_id, ca_entity)
        return entity_id, entity

    @staticmethod
    def generate_certificate(ca_entity):
        entity_id = EntitiesFactory._generate_entity_id()
        entity = Entity(entity_id, ca_entity, is_ca=False)
        return entity_id, entity
