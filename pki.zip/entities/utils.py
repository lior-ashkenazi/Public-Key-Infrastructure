def get_entity_name_from_id(entity_id):
    return "entity" + str(entity_id)
