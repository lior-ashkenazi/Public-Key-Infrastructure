from ssl_networking import socket, ssl


class SSLClient:
    def __init__(self, entity_name, cert_file):
        self.entity_name = entity_name
        self._context = ssl.SSLContext()
        # TODO should they be both a path?
        self._context.load_cert_chain(cert_file)
        self._sock = None
        self._ssock = None

    def __del__(self):
        self.close()

    def connect(self, server_host, server_port):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # TODO maybe problem here? Note there should be comma (self._sock, )
        self._ssock = self._context.wrap_socket(self._sock,)
        self._ssock.connect((server_host, server_port))

    def send(self, msg):
        print(f'\t{str(self.entity_name).capitalize()}: Sending now the message. Good luck for me!')
        self._ssock.send(msg.encode())


    def close(self):
        self._ssock.close()
